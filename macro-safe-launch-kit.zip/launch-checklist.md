# 48-Hour Launch Checklist

- [ ] Read `product-guide.md`
- [ ] Pick launch price: $19 or $29
- [ ] Export markdown files to PDF if desired
- [ ] Zip the product folder for delivery
- [ ] Copy `gumroad-listing.md` into marketplace listing
- [ ] Upload cover image / simple product mockup
- [ ] Publish product listing
- [ ] Post launch message on one owned or social channel
- [ ] Track first 10 visits and first sale
- [ ] Collect objections / questions for v2
